from src.exporters import segments_to_srt
from src.transcriber import TranscriptSegment


def test_segments_to_srt() -> None:
    result = segments_to_srt(
        [TranscriptSegment(start=1.25, end=3.5, text="Hallo Welt")]
    )

    assert result == "1\n00:00:01,250 --> 00:00:03,500\nHallo Welt\n"
